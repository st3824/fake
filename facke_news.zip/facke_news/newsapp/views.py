from django.shortcuts import render,redirect
import sys
# Create your views here.
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request,'about.html')

def alogin(request):

    if request.method == "POST":
        
        username=request.POST.get('username')
        password=request.POST.get('password')

        try:
            
            print("Hello world",username,password)
            #print("retive from database",Adminlogin.objects.get(username))
            #enter=Adminlogin.objects.get(username=username,password=password)

            if(username=="admin" and password=="admin"):
                request.session["name"]=username 
                return redirect('AdminHome')
        except:
            print("Unexpected error:", sys.exc_info()[0])
            print("Unexpected error:", sys.exc_info()[1])
            print("Unexpected error:", sys.exc_info()[2])
            pass

    return render(request,'adminlogin.html')

def rlogin(request):
    return render(request,'reviewlogin.html')

def AdminHome(request):
    return render(request,'AdminHome.html')

def ulogin(request):
    return render(request,'userlogin.html')

