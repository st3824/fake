"""facke_news URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from newsapp import views as f_news

urlpatterns = [
    url('admin/', admin.site.urls),

    url(r'^$', f_news.index, name='index'),
    url(r'^about/$', f_news.about, name='about'),
    url(r'^alogin/$', f_news.alogin, name='alogin'),
    url(r'^rlogin/$', f_news.rlogin, name='rlogin'),
    url(r'^ulogin/$', f_news.ulogin, name='ulogin'),
    url(r'^AdminHome/$', f_news.AdminHome, name='AdminHome'),


]